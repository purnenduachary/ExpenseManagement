package com.java.ejb.dao;

public interface ExpenseSplitDao {

}
