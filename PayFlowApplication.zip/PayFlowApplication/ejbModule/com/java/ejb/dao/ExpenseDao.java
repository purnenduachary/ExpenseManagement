package com.java.ejb.dao;

public class ExpenseDao {

}
