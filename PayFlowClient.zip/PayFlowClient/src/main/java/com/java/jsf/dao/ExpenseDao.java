package com.java.jsf.dao;

public class ExpenseDao {

}
