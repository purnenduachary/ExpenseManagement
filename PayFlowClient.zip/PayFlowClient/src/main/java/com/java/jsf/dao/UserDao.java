package com.java.jsf.dao;

import java.util.List;

import com.java.ejb.model.User;

public interface UserDao {
	
	List<User> showAllUserH();

}
