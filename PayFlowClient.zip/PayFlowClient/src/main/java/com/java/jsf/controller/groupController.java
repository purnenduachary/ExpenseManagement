package com.java.jsf.controller;

public class groupController {

}
