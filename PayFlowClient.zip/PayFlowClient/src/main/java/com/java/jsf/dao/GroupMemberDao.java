package com.java.jsf.dao;

import java.util.List;

import com.java.jsf.model.GroupMember;

public interface GroupMemberDao {
	
	List<GroupMember> showAllGroup();

}
