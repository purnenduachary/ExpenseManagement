package com.java.jsf.dao;

public interface ExpenseSplitDao {

}
